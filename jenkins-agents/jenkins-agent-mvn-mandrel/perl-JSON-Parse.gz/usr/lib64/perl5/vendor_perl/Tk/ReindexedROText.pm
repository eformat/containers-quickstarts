use strict;
package Tk::ReindexedROText;

use vars qw($VERSION);
$VERSION = '4.004'; # $Id: //depot/Tkutf8/TextList/ReindexedROText.pm#4 $

use Tk::Reindex qw(Tk::ROText);
use base qw(Tk::Reindex Tk::ROText);
Construct Tk::Widget 'ReindexedROText';

1;


